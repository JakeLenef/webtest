export function Footer() {
    return (
        <footer className="bg-slate-800 px-5 py-10 text-center text-sm text-white/70">
            <p>© 2025 Lumeo. All rights reserved.</p>
        </footer>
    );
}
