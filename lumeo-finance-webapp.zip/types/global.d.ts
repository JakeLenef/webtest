declare global {
    interface Window {
        confetti: any;
        formWasJustSubmitted: boolean;
    }
}

export {};
